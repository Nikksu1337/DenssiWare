# Rixile a Fork of Elixir

Todolist:
Proper Threading
Individual Class and files for each features
Cleaning up Code
