#include "mainkamat.h"

bool bhackxaxaToggle = false; //Bhop
bool radhackToggle = false; //Radar


float wear;
int Quality;
int paintKit;
typedef struct {
	float x, y, z;
}Vector;


Misc *pMiscxaxa = new Misc();

void Misc::Bhophackxaxa() //Bhop
{
	while (true)
	{
		if (GetAsyncKeyState(VK_F9)) // Toggle Key
		{
			bhackxaxaToggle = !bhackxaxaToggle;
			if (bhackxaxaToggle) std::cout << "Bhop is ON" << std::endl;
			else std::cout << "Bhop is OFF" << std::endl;
			Sleep(200);
		}
		SaveCPU(1);
		if (!bhackxaxaToggle) continue;
		if (GetAsyncKeyState(VK_SPACE))
		{
			if (!pLocal->InAir())
			{
				m->WriteMem<int>(m->cDll.dwBase + offsets::dwForceJump, 6);
			}
		}
	}
}

void Misc::Radarhackxaxa() //Radar
{
	if (GetAsyncKeyState(VK_F10)) // Toggle Key
	{
		radhackToggle = !radhackToggle;
		if (radhackToggle) std::cout << "Radar ON" << std::endl;
		else std::cout << "Radar OFF" << std::endl;
		SaveCPU(200);
	}

	SaveCPU(1); 
	if (!radhackToggle) return; 

	for (int i = 1; i < 64; i++)
	{
		int dwEntity = m->ReadMem<int>(m->cDll.dwBase + offsets::entityList + i * 0x10); 
		bool dormant = pEntity->getEntityDormantStatus(dwEntity); 

		if (dormant) continue; 

		int pEntTeam = pEntity->getEntityTeamNum(dwEntity); 

		if (pEntTeam == pLocal->getTeamNum()) continue; 

		m->WriteMem<int>(dwEntity + offsets::m_bSpotted, true); 
	}
}
