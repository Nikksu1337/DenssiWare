#pragma once
#include "Includes.h"

class Misc
{
public:
	void Radarhackxaxa(); //Radar
	static void Bhophackxaxa(); //Bhop
	void RCS();
	void SkinChanger();
	void fovChanger();
	void Aimbot();
};

extern Misc *pMiscxaxa;