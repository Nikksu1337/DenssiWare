#include "Includes.h"
#include "Visuals.h"
#include "mainkamat.h"

/*
 _________        ____        ____    __    __________      ____        ___  ___    __
|   ______|      /    \      |    \  |  |  |___    ___|    /    \       \  \/  /   |  |
|  |   ___      /      \     |     \ |  |      |  |       /      \       \    /    |  |
|  |  |_  |    /  ____  \    |      \|  |      |  |      /  ____  \      |    |    |  |              
|  |____| |   /  /    \  \   |   |\     |      |  |     /  /    \  \    /  /\  \   |  |     
|_________|  /__/      \__\  |___| \____|      |__|    /__/      \__\  /__/  \__\  |__|

*/








int main()
{
	PrintConsole("DenssiWare");
	PrintConsole("Shit Cheat imo");
	PrintOffsetsConsole("Client Base Address: 0x", m->cDll.dwBase);
	PrintConsole("Pattern Scanning...\n");
	updateOffsets();
	PrintOffsetsConsole("Glow Pointer: 0x", offsets::dwGlow); 
	PrintOffsetsConsole("Local Player: 0x", offsets::localPlayer);
	PrintOffsetsConsole("Entity List: 0x", offsets::entityList);
	PrintOffsetsConsole("Client State: 0x", offsets::dwClientState);
	PrintOffsetsConsole("ForceJump: 0x", offsets::dwForceJump);
	PrintOffsetsConsole("ForceAttack: 0x", offsets::dwForceAttack);
	PrintOffsetsConsole("CState Viewangles: 0x", offsets::dwClientState_ViewAngles);

	CreateThread(0, 0, (LPTHREAD_START_ROUTINE)pMiscxaxa->Bhophackxaxa, 0, 0, 0);

	std::cout << "\n";
	//std::cout << "RCS is VK_F4 \n";
	//std::cout << "SkinChanger is VK_F5 \n"; 
	//std::cout << "Fov Changer is VK_F6 \n"; 
	std::cout << "Bhop is VK_F7 \n";
	std::cout << "Glow is VK_F8 \n";
	std::cout << "Chams is VK_F9 \n";
	std::cout << "Radar is VK_F10 \n";
	std::cout << "\n";

	while (true)
	{
		pVisualsxd->GlowESPhackxaxa(); //GlowEsp
		pVisualsxd->Chamshackxaxa(); //Chams
		pMiscxaxa->Radarhackxaxa(); //Radar
	}
	delete m;
	return 0;
}

