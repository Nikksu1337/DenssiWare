#include "Visuals.h"

bool fToggle = false;
bool glowToggle = false;
bool chamsToggle = false;
float flashopacity = 255.f; 

Visuals *pVisualsxd = new Visuals(); //Visuals

void Visuals::GlowESPhackxaxa() //GlowESp
{
	if (GetAsyncKeyState(VK_F8)) // Toggle Key
	{
		glowToggle = !glowToggle;
		if (glowToggle) std::cout << "Glow is ON" << std::endl;
		else std::cout << "Glow is OFF" << std::endl;
		SaveCPU(200);
	}

	SaveCPU(1);
	if (!glowToggle) return;

	static DWORD objGlowArray = 0; 
	static int objCount = 0; 

	objGlowArray = m->ReadMem<DWORD>(m->cDll.dwBase + offsets::dwGlow); 
	objCount = m->ReadMem<DWORD>(m->cDll.dwBase + offsets::dwGlow + 0x4); 

	if (objGlowArray == 0) return;

	for (int i = 1; i < objCount; i++) 
	{
		DWORD mObj = objGlowArray + i * sizeof(glow_t);
		glow_t vGlowObj = m->ReadMem<glow_t>(mObj);

		if (pEntity->getHealth(vGlowObj.dwBase) <= 0) continue; 

		if (pEntity->getEntityDormantStatus(vGlowObj.dwBase)) continue;

		if (!pEntity->getClassID(vGlowObj.dwBase) == 38) continue; 

		

		vGlowObj.r = .255f; // Red Color Glow
		vGlowObj.m_flGlowAlpha = 250.f; // setting Alpha in glow
		vGlowObj.g = .0f; // Green Color Glow
		vGlowObj.b = .0f; // Blue Color Glow
		vGlowObj.m_bRenderWhenOccluded = true; 
		vGlowObj.m_bRenderWhenUnoccluded = false;
		vGlowObj.m_bFullBloomRender = false;
		vGlowObj.m_nGlowStyle = 0; 


		m->WriteMem(mObj, vGlowObj); 
	}
}

void Visuals::Chamshackxaxa() //Chams
{
	if (GetAsyncKeyState(VK_F7)) // toggle status
	{
		chamsToggle = !chamsToggle;
		if (chamsToggle) std::cout << "Chams ON" << std::endl;
		else std::cout << "Chams OFF" << std::endl;
		SaveCPU(200);
	}
	Color obj; // Defining the color struct
	SaveCPU(1);
	if (!chamsToggle) return; // return if feature isnt toggled
	for (int i = 1; i < 64; i++)
	{
		int dwEntity = m->ReadMem<int>(m->cDll.dwBase + offsets::entityList + i * 0x10);
		bool dormant = pEntity->getEntityDormantStatus(dwEntity);

		if (dormant) continue;

		int pEntTeam = pEntity->getEntityTeamNum(dwEntity);

		if (pEntTeam == pLocal->getTeamNum()) continue;

		obj.r = 0; // setting the red color here
		obj.g = 200; // green here
		obj.b = 200; // blue here
		obj.a = 255; // alpha here

		m->WriteMem<Color>(dwEntity + 0x70, obj); // writing the object
	}
}
