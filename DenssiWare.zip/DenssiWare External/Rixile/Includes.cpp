#include "Includes.h"

MemManager *m = new MemManager();

void SaveCPU(int ms)
{
	return std::this_thread::sleep_for(std::chrono::milliseconds(ms));
}

void PrintOffsetsConsole(const char* text, DWORD Offset) 
{
	std::cout << text << std::hex << Offset << std::endl;
}

void PrintConsole(const char* text)
{
	std::cout << text << std::endl;
}