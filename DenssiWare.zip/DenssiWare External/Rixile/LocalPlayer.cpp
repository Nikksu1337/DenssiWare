#include "LocalPlayer.h"

LocalPlayer *pLocal = new LocalPlayer();

LocalPlayer::LocalPlayer() {} 
LocalPlayer::~LocalPlayer() {} 

DWORD LocalPlayer::getLocalPlayer() // getting the localplayer
{
	return m->ReadMem<DWORD>(m->cDll.dwBase + offsets::localPlayer);
}

int LocalPlayer::getTeamNum() 
{
	return m->ReadMem<int>(pLocal->getLocalPlayer() + offsets::teamNum);
}

int LocalPlayer::getFlags()
{
	return m->ReadMem<int>(pLocal->getLocalPlayer() + offsets::m_fFlags);
}

int LocalPlayer::getMoveType()
{
	return m->ReadMem<int>(pLocal->getLocalPlayer() + offsets::m_MoveType);
}

bool LocalPlayer::InAir() 
{
	return getFlags() == 256 || getFlags() == 258 || getFlags() == 260 || getFlags() == 262;
}