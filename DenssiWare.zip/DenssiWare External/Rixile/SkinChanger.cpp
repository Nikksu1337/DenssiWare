void SkinChanger() // i fucking hate skinchangers and wont continue this prob I FUCKING HATED TO GET MINE SETUP WITH VARIOUS GHETTO METHODS
{
	if (GetAsyncKeyState(VK_F8))
	{
		sToggle = !sToggle;
		if (sToggle) std::cout << "Skinchanger is ON" << std::endl;
		else std::cout << "Skinchanger is OFF" << std::endl;
		SaveCPU(200);
	}
	if (!sToggle) return;
	for (int j = 1; j <= 3; j++) // i wanna die for loop scanning 3 times
	{
		DWORD WeapEnt = m->ReadMem<DWORD>(pLocal->getLocalPlayer() + offsets::m_hMyWeapons + j * 0x4) & 0xFFF; // weapon entity
		DWORD weaponBase = m->ReadMem<DWORD>(m->cDll.dwBase + offsets::entityList + (WeapEnt - 1) * 0x10); // weapon id
		short weaponid = m->ReadMem<short>(weaponBase + offsets::m_iItemDefinitionIndex);
		DWORD cState = m->ReadMem<DWORD>(m->eDll.dwBase + 0x589B34); // getting clientstate with engine
		if (weaponid == 0) continue; // continue if id == 0
		else if (weaponid > 64) continue; // same is above if its greater then 64
		else
		{
			switch (weaponid)
			{
			case 1: { paintKit = 22; } // case1 = deagle
			case 7: { paintKit = 22; } // case 7 = ak47
			}
		}
		int currentPaintKit = m->ReadMem<int>(weaponBase + offsets::m_nFallbackPaintKit); // getting current paintkit
		if (currentPaintKit != paintKit && currentPaintKit != -1)
		{
			m->WriteMem<int>(weaponBase + offsets::m_nFallbackPaintKit, paintKit); // writing our paintkit on our weapon base
			m->WriteMem<float>(weaponBase + offsets::m_flFallbackWear, wear); // writing our wear on our weaponbase
			m->WriteMem<int>(weaponBase + offsets::m_iEntityQuality, Quality); // same as above only quality
			m->WriteMem<int>(weaponBase + offsets::m_iItemIDHigh, -1);
			if (GetAsyncKeyState(VK_F4))
				m->WriteMem<int>(cState + 0x174, -1); // forceupdate i wanna fk die
		}
	}
}