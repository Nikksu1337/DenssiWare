#include "Entity.h"

Entity *pEntity = new Entity();

Entity::Entity() {} 
Entity::~Entity() {} 

int Entity::getEntityTeamNum(int EntityList) 
{
	return m->ReadMem<int>(EntityList + offsets::teamNum);
}

bool Entity::getEntityDormantStatus(int EntityList)
{
	return m->ReadMem<bool>(EntityList + offsets::bDormant);
}

int Entity::getClassID(int entity) 
{
	DWORD dwClientNetworkable = m->ReadMem<int>(entity + 0x8);
	DWORD dwGetClientClassFn = m->ReadMem<int>(dwClientNetworkable + 2 * 0x4); 
    DWORD dwEntityClientClass = m->ReadMem<int>(dwGetClientClassFn + 1);
	
	return m->ReadMem<int>(dwEntityClientClass + 0x14); 
}

int Entity::getHealth(int entity) 
{
	return  m->ReadMem<int>(entity + offsets::m_iHealth);
}
